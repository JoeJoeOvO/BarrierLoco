#!/usr/bin/env bash
# Select a skill in the unified repository using the existing Isaac Lab environment.
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
python_bin="${BARRIERLOCO_PYTHON:-/home/joey/miniconda3/envs/env_isaaclab/bin/python}"
if [[ $# -lt 2 ]]; then
    echo "Usage: $0 {highplatform|multiskill|omnijump} {train|play|sweep|record|verify|test|list|python} [arguments]"
    exit 2
fi
skill="$1"
operation="$2"
shift 2
train_args=()
play_args=()
case "$skill" in
    highplatform)
        task=OmniBot-Go2W-HighPlatform-MLP-v0
        bundle=deploy/policy/go2w/highplatform_rough_mlp_20260922
        model=model_9998.pt
        ;;
    multiskill)
        task=OmniBot-Go2W-Gait-Curriculum-Flat-MLP-v0
        bundle=deploy/policy/go2w/gait_curriculum_v1
        model=model_29999.pt
        ;;
    omnijump)
        task=OmniBot-Go2W-Jump-MLP-v0
        bundle=deploy/policy/go2w/jump_smooth_mlp_20261009
        model=model_9998.pt
        train_args=(--jump_stage skill)
        play_args=(--jump_stage speed)
        ;;
    *) echo "Unknown skill: $skill" >&2; exit 2 ;;
esac
skill_root="$root"
cd -- "$skill_root"
# Prefer this repository even when another editable installation exists.
export PYTHONPATH="$skill_root:$skill_root/locolab${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONUNBUFFERED=1
case "$operation" in
    train)
        if [[ "$skill" == multiskill ]]; then
            # V1 warm start remains available; --from-scratch explicitly disables all weight loading.
            train_args=(--num_envs 1024 --max_iterations 30000 --validate-finite)
            supplied_init=false
            for argument in "$@"; do
                case "$argument" in --from-scratch|--resume|--resume=*|--init_checkpoint|--init_checkpoint=*) supplied_init=true ;; esac
            done
            if [[ "$supplied_init" == false ]]; then
                train_args+=(--init_checkpoint "$root/deploy/policy/go2w/gait_wtw_height50_20260920/model_4999.pt")
            fi
        fi
        exec "$python_bin" locolab/scripts/locomotion/train.py --task "$task" \
            --num_envs 64 --logger tensorboard "${train_args[@]}" "$@"
        ;;
    play)
        if [[ "$skill" == multiskill ]]; then
            exec "$python_bin" scripts/multiskill/cmd_sweep.py --extended --checkpoint "$root/$bundle/$model" "$@"
        fi
        exec "$python_bin" locolab/scripts/locomotion/play.py --task "$task" \
            --num_envs 1 --checkpoint "$skill_root/$bundle/$model" "${play_args[@]}" "$@"
        ;;
    sweep|record)
        [[ "$skill" == multiskill ]] || { echo "sweep/record are multiskill operations" >&2; exit 2; }
        if [[ "$operation" == sweep ]]; then
            exec "$python_bin" scripts/multiskill/cmd_sweep.py --extended --checkpoint "$root/$bundle/$model" "$@"
        fi
        exec "$python_bin" scripts/multiskill/record_cmd_sweep.py --checkpoint "$root/$bundle/$model" "$@"
        ;;
    verify)
        if [[ "$skill" == multiskill ]]; then
            echo "verify checks the bundled author export; use sweep to inspect the V1 curriculum checkpoint."
            bundle=deploy/policy/go2w/gait_wtw_height50_20260920
        fi
        export CUDA_VISIBLE_DEVICES=''
        exec "$python_bin" "$bundle/export_policy.py" --verify-only "$@"
        ;;
    test) exec "$python_bin" -m pytest "$@" ;;
    list) exec "$python_bin" locolab/scripts/list_envs.py "$@" ;;
    python) exec "$python_bin" "$@" ;;
    *) echo "Unknown operation: $operation" >&2; exit 2 ;;
esac
