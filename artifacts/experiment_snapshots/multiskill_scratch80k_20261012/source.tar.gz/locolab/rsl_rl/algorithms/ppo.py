# Copyright (c) 2021-2025, ETH Zurich and NVIDIA CORPORATION
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

from itertools import chain

import torch
import torch.nn as nn
import torch.optim as optim
from rsl_rl.modules import ActorCritic, ActorCriticCNN, ActorCriticDreamWaQ, ActorCriticRecurrent, DecoderCollection
from rsl_rl.modules.rnd import RandomNetworkDistillation
from rsl_rl.storage import RolloutStorage
from rsl_rl.utils import resolve_callable, unpad_trajectories
from tensordict import TensorDict


class PPO:
    """Proximal Policy Optimization algorithm (https://arxiv.org/abs/1707.06347)."""

    policy: ActorCritic | ActorCriticRecurrent | ActorCriticCNN | ActorCriticDreamWaQ
    """The actor critic module."""

    _normalize_auxiliary_by_mini_batches: bool = True
    """If True, auxiliary loss is divided by num_mini_batches (legacy DreamWaQ behavior)."""

    def __init__(
        self,
        policy: ActorCritic | ActorCriticRecurrent | ActorCriticCNN | ActorCriticDreamWaQ,
        storage: RolloutStorage,
        num_learning_epochs: int = 5,
        num_mini_batches: int = 4,
        clip_param: float = 0.2,
        gamma: float = 0.99,
        lam: float = 0.95,
        value_loss_coef: float = 1.0,
        entropy_coef: float = 0.01,
        learning_rate: float = 0.001,
        max_grad_norm: float = 1.0,
        use_clipped_value_loss: bool = True,
        schedule: str = "adaptive",
        desired_kl: float = 0.01,
        normalize_advantage_per_mini_batch: bool = False,
        device: str = "cpu",
        # RND parameters
        rnd_cfg: dict | None = None,
        # Symmetry parameters
        symmetry_cfg: dict | None = None,
        # Decoder parameters
        decoder_cfg: dict | None = None,
        # Distributed training parameters
        multi_gpu_cfg: dict | None = None,
    ) -> None:
        # Device-related parameters
        self.device = device
        self.is_multi_gpu = multi_gpu_cfg is not None

        # Multi-GPU parameters
        if multi_gpu_cfg is not None:
            self.gpu_global_rank = multi_gpu_cfg["global_rank"]
            self.gpu_world_size = multi_gpu_cfg["world_size"]
        else:
            self.gpu_global_rank = 0
            self.gpu_world_size = 1

        # RND components
        if rnd_cfg:
            # Extract parameters used in ppo
            rnd_lr = rnd_cfg.pop("learning_rate", 1e-3)
            # Create RND module
            self.rnd = RandomNetworkDistillation(device=self.device, **rnd_cfg)
            # Create RND optimizer
            params = self.rnd.predictor.parameters()
            self.rnd_optimizer = optim.Adam(params, lr=rnd_lr)
        else:
            self.rnd = None
            self.rnd_optimizer = None

        # Symmetry components
        if symmetry_cfg is not None:
            # Check if symmetry is enabled
            use_symmetry = symmetry_cfg["use_data_augmentation"] or symmetry_cfg["use_mirror_loss"]
            # Print that we are not using symmetry
            if not use_symmetry:
                print("Symmetry not used for learning. We will use it for logging instead.")
            # Resolve the data augmentation function (supports string names or direct callables)
            symmetry_cfg["data_augmentation_func"] = resolve_callable(symmetry_cfg["data_augmentation_func"])
            # Check valid configuration
            if not callable(symmetry_cfg["data_augmentation_func"]):
                raise ValueError(
                    "Symmetry configuration exists but the function is not callable: "
                    f"{symmetry_cfg['data_augmentation_func']}"
                )
            # Check if the policy is compatible with symmetry
            if isinstance(policy, ActorCriticRecurrent):
                raise ValueError("Symmetry augmentation is not supported for recurrent policies.")
            # Store symmetry configuration
            self.symmetry = symmetry_cfg
        else:
            self.symmetry = None

        # Decoder components
        self.actor_decoders = None
        self.critic_decoders = None
        self.actor_decoder_optimizer = None
        self.critic_decoder_optimizer = None
        self.actor_decoder_loss_weight = 0.0
        self.critic_decoder_loss_weight = 0.0

        if decoder_cfg is not None and policy.is_recurrent:
            for decoder_type in ["actor", "critic"]:
                branch_cfg = decoder_cfg.get(decoder_type)
                if branch_cfg is not None:
                    self._initialize_decoder(decoder_type, branch_cfg, policy)
        elif decoder_cfg is not None and not policy.is_recurrent:
            raise ValueError("Decoder auxiliary losses are only supported for recurrent policies.")

        # PPO components
        self.policy = policy
        self.policy.to(self.device)

        # Create the optimizer
        self.optimizer = optim.Adam(self.policy.parameters(), lr=learning_rate)

        # Add storage
        self.storage = storage
        self.transition = RolloutStorage.Transition()

        # PPO parameters
        self.clip_param = clip_param
        self.num_learning_epochs = num_learning_epochs
        self.num_mini_batches = num_mini_batches
        self.value_loss_coef = value_loss_coef
        self.entropy_coef = entropy_coef
        self.gamma = gamma
        self.lam = lam
        self.max_grad_norm = max_grad_norm
        self.use_clipped_value_loss = use_clipped_value_loss
        self.desired_kl = desired_kl
        self.schedule = schedule
        self.learning_rate = learning_rate
        self.normalize_advantage_per_mini_batch = normalize_advantage_per_mini_batch

    def _initialize_decoder(self, decoder_type: str, decoder_cfg: dict, policy: ActorCriticRecurrent) -> None:
        if "configs" not in decoder_cfg:
            raise ValueError(f"decoder_cfg['{decoder_type}'] must contain 'configs'")

        memory_module = policy.memory_a if decoder_type == "actor" else policy.memory_c
        decoders = DecoderCollection(
            input_dim=memory_module.rnn.hidden_size,
            decoder_configs=decoder_cfg["configs"],
        ).to(self.device)
        optimizer = optim.Adam(decoders.parameters(), lr=decoder_cfg.get("learning_rate", 1e-3))

        setattr(self, f"{decoder_type}_decoders", decoders)
        setattr(self, f"{decoder_type}_decoder_optimizer", optimizer)
        setattr(self, f"{decoder_type}_decoder_loss_weight", decoder_cfg.get("loss_weight", 1.0))

    def act(self, obs: TensorDict) -> torch.Tensor:
        if self.policy.is_recurrent:
            self.transition.hidden_states = self.policy.get_hidden_states()
        # Compute the actions and values
        self.transition.actions = self.policy.act(obs).detach()
        self.transition.values = self.policy.evaluate(obs).detach()
        self.transition.actions_log_prob = self.policy.get_actions_log_prob(self.transition.actions).detach()
        self.transition.action_mean = self.policy.action_mean.detach()
        self.transition.action_sigma = self.policy.action_std.detach()
        # Record observations before env.step()
        self.transition.observations = obs
        return self.transition.actions

    def process_env_step(
        self, obs: TensorDict, rewards: torch.Tensor, dones: torch.Tensor, extras: dict[str, torch.Tensor]
    ) -> None:
        # Update the normalizers
        self.policy.update_normalization(obs)
        if self.rnd:
            self.rnd.update_normalization(obs)

        # Record the next observations (obs after env.step is o_{t+1}).
        self.transition.next_observations = obs

        # Record the rewards and dones
        # Note: We clone here because later on we bootstrap the rewards based on timeouts
        self.transition.rewards = rewards.clone()
        self.transition.dones = dones

        # Compute the intrinsic rewards and add to extrinsic rewards
        if self.rnd:
            # Compute the intrinsic rewards
            self.intrinsic_rewards = self.rnd.get_intrinsic_reward(obs)
            # Add intrinsic rewards to extrinsic rewards
            self.transition.rewards += self.intrinsic_rewards

        # Bootstrapping on time outs
        if "time_outs" in extras:
            self.transition.rewards += self.gamma * torch.squeeze(
                self.transition.values * extras["time_outs"].unsqueeze(1).to(self.device), 1
            )

        # Record the transition
        self.storage.add_transition(self.transition)
        self.transition.clear()
        self.policy.reset(dones)

    def compute_returns(self, obs: TensorDict) -> None:
        st = self.storage
        # Compute value for the last step
        last_values = self.policy.evaluate(obs).detach()
        # Compute returns and advantages
        advantage = 0
        for step in reversed(range(st.num_transitions_per_env)):
            # If we are at the last step, bootstrap the return value
            next_values = last_values if step == st.num_transitions_per_env - 1 else st.values[step + 1]
            # 1 if we are not in a terminal state, 0 otherwise
            next_is_not_terminal = 1.0 - st.dones[step].float()
            # TD error: r_t + gamma * V(s_{t+1}) - V(s_t)
            delta = st.rewards[step] + next_is_not_terminal * self.gamma * next_values - st.values[step]
            # Advantage: A(s_t, a_t) = delta_t + gamma * lambda * A(s_{t+1}, a_{t+1})
            advantage = delta + next_is_not_terminal * self.gamma * self.lam * advantage
            # Return: R_t = A(s_t, a_t) + V(s_t)
            st.returns[step] = advantage + st.values[step]
        # Compute the advantages
        st.advantages = st.returns - st.values
        # Normalize the advantages if per minibatch normalization is not used
        if not self.normalize_advantage_per_mini_batch:
            st.advantages = (st.advantages - st.advantages.mean()) / (st.advantages.std() + 1e-8)

    def _compute_auxiliary_losses(
        self,
        obs_batch: TensorDict,
        next_obs_batch: TensorDict,
        dones_batch: torch.Tensor,
        actions_batch: torch.Tensor,
        returns_batch: torch.Tensor,
    ) -> dict[str, torch.Tensor] | None:
        # Fallback: if the policy exposes auxiliary losses but a specialized PPO
        # subclass (for example PPODreamWaQ) is not used, warn and compute
        # them so stale configs do not silently drop auxiliary objectives.
        if hasattr(self.policy, "compute_auxiliary_losses"):
            import warnings

            warnings.warn(
                f"Policy {type(self.policy).__name__} has auxiliary losses but is paired with base PPO. "
                "Use the matching PPO subclass for correct behavior.",
                stacklevel=2,
            )
            return self.policy.compute_auxiliary_losses(
                obs_batch,
                next_obs=next_obs_batch,
                dones=dones_batch,
                actions=actions_batch,
                returns=returns_batch,
            )
        del obs_batch, next_obs_batch, dones_batch, actions_batch, returns_batch
        return None

    def _auxiliary_total_key(self) -> str | None:
        if not hasattr(self.policy, "compute_auxiliary_losses"):
            return None
        # Subclasses (for example PPODreamWaQ) override this to return their
        # specific key.  When the base PPO is paired with an auxiliary-loss
        # policy via a stale config, try the common key names so the fallback
        # path works instead of raising.
        return "auxiliary_total"

    def _optimize_additional_modules(
        self,
        obs_batch: TensorDict,
        next_obs_batch: TensorDict,
        dones_batch: torch.Tensor,
        actions_batch: torch.Tensor,
        returns_batch: torch.Tensor,
    ) -> dict[str, float] | None:
        del obs_batch, next_obs_batch, dones_batch, actions_batch, returns_batch

    def get_additional_checkpoint_state(self) -> dict[str, object]:
        return {}

    def load_additional_checkpoint_state(self, loaded_dict: dict, load_optimizer: bool) -> None:
        del loaded_dict, load_optimizer

    def _compute_surrogate_loss(
        self,
        ratio: torch.Tensor,
        advantages_batch: torch.Tensor,
        returns_batch: torch.Tensor,
        value_batch: torch.Tensor,
    ) -> torch.Tensor:
        del returns_batch, value_batch
        surrogate = -torch.squeeze(advantages_batch) * ratio
        surrogate_clipped = -torch.squeeze(advantages_batch) * torch.clamp(
            ratio, 1.0 - self.clip_param, 1.0 + self.clip_param
        )
        return torch.max(surrogate, surrogate_clipped).mean()

    def update(self) -> dict[str, float]:
        mean_value_loss = 0
        mean_surrogate_loss = 0
        mean_entropy = 0
        # RND loss
        mean_rnd_loss = 0 if self.rnd else None
        # Symmetry loss
        mean_symmetry_loss = 0 if self.symmetry else None
        # Decoder losses
        mean_actor_decoder_loss = 0 if self.actor_decoders else None
        mean_critic_decoder_loss = 0 if self.critic_decoders else None
        mean_auxiliary_losses: dict[str, float] = {}
        mean_additional_losses: dict[str, float] = {}

        # Get mini batch generator
        if self.policy.is_recurrent:
            generator = self.storage.recurrent_mini_batch_generator(self.num_mini_batches, self.num_learning_epochs)
        else:
            generator = self.storage.mini_batch_generator(self.num_mini_batches, self.num_learning_epochs)

        # Iterate over batches
        for (
            obs_batch,
            next_obs_batch,
            dones_batch,
            actions_batch,
            target_values_batch,
            advantages_batch,
            returns_batch,
            old_actions_log_prob_batch,
            old_mu_batch,
            old_sigma_batch,
            hidden_states_batch,
            masks_batch,
        ) in generator:
            num_aug = 1  # Number of augmentations per sample. Starts at 1 for no augmentation.
            original_batch_size = obs_batch.batch_size[0]

            # Check if we should normalize advantages per mini batch
            if self.normalize_advantage_per_mini_batch:
                with torch.no_grad():
                    advantages_batch = (advantages_batch - advantages_batch.mean()) / (advantages_batch.std() + 1e-8)

            # Perform symmetric augmentation
            if self.symmetry and self.symmetry["use_data_augmentation"]:
                # Augmentation using symmetry
                data_augmentation_func = self.symmetry["data_augmentation_func"]
                # Returned shape: [batch_size * num_aug, ...]
                obs_batch, actions_batch = data_augmentation_func(
                    obs=obs_batch,
                    actions=actions_batch,
                    env=self.symmetry["_env"],
                )
                # Compute number of augmentations per sample
                num_aug = int(obs_batch.batch_size[0] / original_batch_size)
                # Repeat the rest of the batch
                old_actions_log_prob_batch = old_actions_log_prob_batch.repeat(num_aug, 1)
                target_values_batch = target_values_batch.repeat(num_aug, 1)
                advantages_batch = advantages_batch.repeat(num_aug, 1)
                returns_batch = returns_batch.repeat(num_aug, 1)

            # Recompute actions log prob and entropy for current batch of transitions
            # Note: We need to do this because we updated the policy with the new parameters
            self.policy.act(obs_batch, masks=masks_batch, hidden_state=hidden_states_batch[0])
            actions_log_prob_batch = self.policy.get_actions_log_prob(actions_batch)
            value_batch = self.policy.evaluate(obs_batch, masks=masks_batch, hidden_state=hidden_states_batch[1])
            # Note: We only keep the entropy of the first augmentation (the original one)
            mu_batch = self.policy.action_mean[:original_batch_size]
            sigma_batch = self.policy.action_std[:original_batch_size]
            entropy_batch = self.policy.entropy[:original_batch_size]

            # Compute KL divergence and adapt the learning rate
            if self.desired_kl is not None and self.schedule == "adaptive":
                with torch.inference_mode():
                    kl = torch.sum(
                        torch.log(sigma_batch / old_sigma_batch + 1.0e-5)
                        + (torch.square(old_sigma_batch) + torch.square(old_mu_batch - mu_batch))
                        / (2.0 * torch.square(sigma_batch))
                        - 0.5,
                        axis=-1,
                    )
                    kl_mean = torch.mean(kl)

                    # Reduce the KL divergence across all GPUs
                    if self.is_multi_gpu:
                        torch.distributed.all_reduce(kl_mean, op=torch.distributed.ReduceOp.SUM)
                        kl_mean /= self.gpu_world_size

                    # Update the learning rate only on the main process
                    # TODO: Is this needed? If KL-divergence is the "same" across all GPUs,
                    #       then the learning rate should be the same across all GPUs.
                    if self.gpu_global_rank == 0:
                        if kl_mean > self.desired_kl * 2.0:
                            self.learning_rate = max(1e-5, self.learning_rate / 1.5)
                        elif kl_mean < self.desired_kl / 2.0 and kl_mean > 0.0:
                            self.learning_rate = min(1e-2, self.learning_rate * 1.5)

                    # Update the learning rate for all GPUs
                    if self.is_multi_gpu:
                        lr_tensor = torch.tensor(self.learning_rate, device=self.device)
                        torch.distributed.broadcast(lr_tensor, src=0)
                        self.learning_rate = lr_tensor.item()

                    # Update the learning rate for all parameter groups
                    for param_group in self.optimizer.param_groups:
                        param_group["lr"] = self.learning_rate

            # Surrogate loss
            ratio = torch.exp(actions_log_prob_batch - torch.squeeze(old_actions_log_prob_batch))
            surrogate_loss = self._compute_surrogate_loss(
                ratio=ratio,
                advantages_batch=advantages_batch,
                returns_batch=returns_batch,
                value_batch=value_batch,
            )

            # Value function loss
            if self.use_clipped_value_loss:
                value_clipped = target_values_batch + (value_batch - target_values_batch).clamp(
                    -self.clip_param, self.clip_param
                )
                value_losses = (value_batch - returns_batch).pow(2)
                value_losses_clipped = (value_clipped - returns_batch).pow(2)
                value_loss = torch.max(value_losses, value_losses_clipped).mean()
            else:
                value_loss = (returns_batch - value_batch).pow(2).mean()

            loss = surrogate_loss + self.value_loss_coef * value_loss - self.entropy_coef * entropy_batch.mean()

            actor_decoder_loss = torch.tensor(0.0, device=self.device)
            critic_decoder_loss = torch.tensor(0.0, device=self.device)

            if self.actor_decoders or self.critic_decoders:
                critic_obs_batch = self.policy.get_critic_obs(obs_batch)
                target_observations = unpad_trajectories(critic_obs_batch, masks_batch)

                if self.actor_decoders:
                    actor_hidden_states = self.policy.hidden_a.squeeze(0)
                    actor_decoder_result = self.actor_decoders.forward_and_compute_losses(
                        hidden_states=actor_hidden_states,
                        target_observations=target_observations,
                    )
                    actor_decoder_loss = actor_decoder_result["loss"]
                    loss = loss + self.actor_decoder_loss_weight * actor_decoder_loss

                if self.critic_decoders:
                    critic_hidden_states = self.policy.hidden_c.squeeze(0)
                    critic_decoder_result = self.critic_decoders.forward_and_compute_losses(
                        hidden_states=critic_hidden_states,
                        target_observations=target_observations,
                    )
                    critic_decoder_loss = critic_decoder_result["loss"]
                    loss = loss + self.critic_decoder_loss_weight * critic_decoder_loss

            auxiliary_losses = self._compute_auxiliary_losses(
                obs_batch,
                next_obs_batch,
                dones_batch,
                actions_batch,
                returns_batch,
            )
            if auxiliary_losses is not None:
                auxiliary_total_key = self._auxiliary_total_key()
                if auxiliary_total_key is None:
                    raise ValueError("Auxiliary loss key must be defined when auxiliary losses are enabled.")
                auxiliary_total = auxiliary_losses.pop(auxiliary_total_key, None)
                if auxiliary_total is None:
                    # Fallback: look for any key ending with '_total' so stale
                    # configs do not silently disable auxiliary objectives.
                    for key in list(auxiliary_losses):
                        if key.endswith("_total"):
                            auxiliary_total = auxiliary_losses.pop(key)
                            break
                if auxiliary_total is None:
                    raise ValueError(f"Auxiliary loss hook must return a '{auxiliary_total_key}' entry.")
                if self._normalize_auxiliary_by_mini_batches:
                    loss = loss + auxiliary_total / self.num_mini_batches
                else:
                    loss = loss + auxiliary_total
                for key, value in auxiliary_losses.items():
                    mean_auxiliary_losses[key] = mean_auxiliary_losses.get(key, 0.0) + value.item()

            # Symmetry loss
            if self.symmetry:
                # Obtain the symmetric actions
                # Note: If we did augmentation before then we don't need to augment again
                if not self.symmetry["use_data_augmentation"]:
                    data_augmentation_func = self.symmetry["data_augmentation_func"]
                    obs_batch, _ = data_augmentation_func(obs=obs_batch, actions=None, env=self.symmetry["_env"])
                    # Compute number of augmentations per sample
                    num_aug = int(obs_batch.shape[0] / original_batch_size)

                # Actions predicted by the actor for symmetrically-augmented observations
                mean_actions_batch = self.policy.act_inference(obs_batch.detach().clone())

                # Compute the symmetrically augmented actions
                # Note: We are assuming the first augmentation is the original one. We do not use the action_batch from
                # earlier since that action was sampled from the distribution. However, the symmetry loss is computed
                # using the mean of the distribution.
                action_mean_orig = mean_actions_batch[:original_batch_size]
                _, actions_mean_symm_batch = data_augmentation_func(
                    obs=None, actions=action_mean_orig, env=self.symmetry["_env"]
                )

                # Compute the loss
                mse_loss = torch.nn.MSELoss()
                symmetry_loss = mse_loss(
                    mean_actions_batch[original_batch_size:], actions_mean_symm_batch.detach()[original_batch_size:]
                )
                # Add the loss to the total loss
                if self.symmetry["use_mirror_loss"]:
                    loss += self.symmetry["mirror_loss_coeff"] * symmetry_loss
                else:
                    symmetry_loss = symmetry_loss.detach()

            # RND loss
            # TODO: Move this processing to inside RND module.
            if self.rnd:
                # Extract the rnd_state
                # TODO: Check if we still need torch no grad. It is just an affine transformation.
                with torch.no_grad():
                    rnd_state_batch = self.rnd.get_rnd_state(obs_batch[:original_batch_size])
                    rnd_state_batch = self.rnd.state_normalizer(rnd_state_batch)
                # Predict the embedding and the target
                predicted_embedding = self.rnd.predictor(rnd_state_batch)
                target_embedding = self.rnd.target(rnd_state_batch).detach()
                # Compute the loss as the mean squared error
                mseloss = torch.nn.MSELoss()
                rnd_loss = mseloss(predicted_embedding, target_embedding)

            # Compute the gradients for PPO and decoders
            self.optimizer.zero_grad()
            if self.actor_decoder_optimizer:
                self.actor_decoder_optimizer.zero_grad()
            if self.critic_decoder_optimizer:
                self.critic_decoder_optimizer.zero_grad()
            loss.backward()
            # Compute the gradients for RND
            if self.rnd:
                self.rnd_optimizer.zero_grad()
                rnd_loss.backward()

            # Collect gradients from all GPUs
            if self.is_multi_gpu:
                self.reduce_parameters()

            # Apply the gradients for PPO
            nn.utils.clip_grad_norm_(self.policy.parameters(), self.max_grad_norm)
            self.optimizer.step()
            if self.actor_decoder_optimizer:
                nn.utils.clip_grad_norm_(self.actor_decoders.parameters(), self.max_grad_norm)
                self.actor_decoder_optimizer.step()
            if self.critic_decoder_optimizer:
                nn.utils.clip_grad_norm_(self.critic_decoders.parameters(), self.max_grad_norm)
                self.critic_decoder_optimizer.step()
            # Apply the gradients for RND
            if self.rnd_optimizer:
                self.rnd_optimizer.step()

            additional_losses = self._optimize_additional_modules(
                obs_batch,
                next_obs_batch,
                dones_batch,
                actions_batch,
                returns_batch,
            )
            if additional_losses is not None:
                for key, value in additional_losses.items():
                    mean_additional_losses[key] = mean_additional_losses.get(key, 0.0) + float(value)

            # Store the losses
            mean_value_loss += value_loss.item()
            mean_surrogate_loss += surrogate_loss.item()
            mean_entropy += entropy_batch.mean().item()
            # RND loss
            if mean_rnd_loss is not None:
                mean_rnd_loss += rnd_loss.item()
            # Symmetry loss
            if mean_symmetry_loss is not None:
                mean_symmetry_loss += symmetry_loss.item()
            # Decoder losses
            if mean_actor_decoder_loss is not None:
                mean_actor_decoder_loss += actor_decoder_loss.item()
            if mean_critic_decoder_loss is not None:
                mean_critic_decoder_loss += critic_decoder_loss.item()

        # Divide the losses by the number of updates
        num_updates = self.num_learning_epochs * self.num_mini_batches
        mean_value_loss /= num_updates
        mean_surrogate_loss /= num_updates
        mean_entropy /= num_updates
        if mean_rnd_loss is not None:
            mean_rnd_loss /= num_updates
        if mean_symmetry_loss is not None:
            mean_symmetry_loss /= num_updates
        if mean_actor_decoder_loss is not None:
            mean_actor_decoder_loss /= num_updates
        if mean_critic_decoder_loss is not None:
            mean_critic_decoder_loss /= num_updates
        for key in mean_auxiliary_losses:
            mean_auxiliary_losses[key] /= num_updates
        for key in mean_additional_losses:
            mean_additional_losses[key] /= num_updates

        # Clear the storage
        self.storage.clear()

        # Construct the loss dictionary
        loss_dict = {
            "value": mean_value_loss,
            "surrogate": mean_surrogate_loss,
            "entropy": mean_entropy,
        }
        if self.rnd:
            loss_dict["rnd"] = mean_rnd_loss
        if self.symmetry:
            loss_dict["symmetry"] = mean_symmetry_loss
        if self.actor_decoders:
            loss_dict["actor_decoder"] = mean_actor_decoder_loss
        if self.critic_decoders:
            loss_dict["critic_decoder"] = mean_critic_decoder_loss
        loss_dict.update(mean_auxiliary_losses)
        loss_dict.update(mean_additional_losses)

        return loss_dict

    def broadcast_parameters(self) -> None:
        """Broadcast model parameters to all GPUs."""
        # Obtain the model parameters on current GPU
        model_params = [self.policy.state_dict()]
        if self.rnd:
            model_params.append(self.rnd.predictor.state_dict())
        if self.actor_decoders:
            model_params.append(self.actor_decoders.state_dict())
        if self.critic_decoders:
            model_params.append(self.critic_decoders.state_dict())
        # Broadcast the model parameters
        torch.distributed.broadcast_object_list(model_params, src=0)
        # Load the model parameters on all GPUs from source GPU
        self.policy.load_state_dict(model_params[0])
        idx = 1
        if self.rnd:
            self.rnd.predictor.load_state_dict(model_params[idx])
            idx += 1
        if self.actor_decoders:
            self.actor_decoders.load_state_dict(model_params[idx])
            idx += 1
        if self.critic_decoders:
            self.critic_decoders.load_state_dict(model_params[idx])

    def reduce_parameters(self) -> None:
        """Collect gradients from all GPUs and average them.

        This function is called after the backward pass to synchronize the gradients across all GPUs.
        """
        # Create a tensor to store the gradients
        grads = [param.grad.view(-1) for param in self.policy.parameters() if param.grad is not None]
        if self.rnd:
            grads += [param.grad.view(-1) for param in self.rnd.parameters() if param.grad is not None]
        if self.actor_decoders:
            grads += [param.grad.view(-1) for param in self.actor_decoders.parameters() if param.grad is not None]
        if self.critic_decoders:
            grads += [param.grad.view(-1) for param in self.critic_decoders.parameters() if param.grad is not None]
        all_grads = torch.cat(grads)

        # Average the gradients across all GPUs
        torch.distributed.all_reduce(all_grads, op=torch.distributed.ReduceOp.SUM)
        all_grads /= self.gpu_world_size

        # Get all parameters
        all_params = self.policy.parameters()
        if self.rnd:
            all_params = chain(all_params, self.rnd.parameters())
        if self.actor_decoders:
            all_params = chain(all_params, self.actor_decoders.parameters())
        if self.critic_decoders:
            all_params = chain(all_params, self.critic_decoders.parameters())

        # Update the gradients for all parameters with the reduced gradients
        offset = 0
        for param in all_params:
            if param.grad is not None:
                numel = param.numel()
                # Copy data back from shared buffer
                param.grad.data.copy_(all_grads[offset : offset + numel].view_as(param.grad.data))
                # Update the offset for the next parameter
                offset += numel
