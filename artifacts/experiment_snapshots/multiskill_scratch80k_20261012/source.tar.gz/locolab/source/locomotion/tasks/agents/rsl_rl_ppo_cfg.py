from __future__ import annotations

from dataclasses import MISSING, field
from typing import Literal, cast

from isaaclab.utils import configclass


@configclass
class RslRlPpoActorCriticCfg:
    class_name: str = "ActorCritic"
    init_noise_std: float = MISSING
    noise_std_type: Literal["scalar", "log"] = "scalar"
    actor_obs_normalization: bool = MISSING
    critic_obs_normalization: bool = MISSING
    actor_hidden_dims: list[int] = MISSING
    critic_hidden_dims: list[int] = MISSING
    activation: str = MISSING


@configclass
class RslRlPpoActorCriticRecurrentCfg(RslRlPpoActorCriticCfg):
    class_name: str = "ActorCriticRecurrent"
    rnn_type: str = MISSING
    rnn_hidden_dim: int = MISSING
    rnn_num_layers: int = MISSING


@configclass
class RslRlPpoActorCriticDreamWaQCfg(RslRlPpoActorCriticCfg):
    class_name: str = "ActorCriticDreamWaQ"
    estimator_hidden_dims: list[int] = field(default_factory=lambda: [128])
    context_decoder_hidden_dims: list[int] = field(default_factory=lambda: [64, 128])
    history_obs_set: str = "policy_history"
    velocity_target_group: str = "dreamwaq_velocity"
    context_target_group: str = "policy"
    context_latent_dim: int = 16
    vae_sigma_min: float = 0.0
    vae_sigma_max: float = 5.0
    reconstruction_mask_indices: list[int] = field(default_factory=list)


@configclass
class RslRlPpoAlgorithmCfg:
    class_name: str = "PPO"
    num_learning_epochs: int = MISSING
    num_mini_batches: int = MISSING
    learning_rate: float = MISSING
    schedule: str = MISSING
    gamma: float = MISSING
    lam: float = MISSING
    entropy_coef: float = MISSING
    desired_kl: float = MISSING
    max_grad_norm: float = MISSING
    value_loss_coef: float = MISSING
    use_clipped_value_loss: bool = MISSING
    clip_param: float = MISSING
    normalize_advantage_per_mini_batch: bool = False
    rnd_cfg: dict | None = None
    symmetry_cfg: dict | None = None


@configclass
class RslRlPpoDreamWaQAlgorithmCfg(RslRlPpoAlgorithmCfg):
    class_name: str = "PPODreamWaQ"
    vae_learning_rate: float = 1.0e-3
    kl_weight: float = 0.1


@configclass
class RslRlOnPolicyRunnerCfg:
    class_name: str = "OnPolicyRunner"
    seed: int = 42
    device: str = "cuda:0"
    num_steps_per_env: int = MISSING
    max_iterations: int = MISSING
    empirical_normalization: bool | None = None
    obs_groups: dict[str, list[str]] = field(default_factory=dict)
    clip_actions: float | None = None
    save_interval: int = MISSING
    experiment_name: str = MISSING
    run_name: str = ""
    logger: Literal["tensorboard", "neptune", "wandb"] = "tensorboard"
    neptune_project: str = "isaaclab"
    wandb_project: str = "isaaclab"
    wandb_entity: str | None = None
    wandb_group: str | None = None
    resume: bool = False
    # ``experiment_name`` is always the output tree; this optional field is input-only.
    resume_experiment_name: str | None = None
    load_run: str = ".*"
    load_checkpoint: str = "model_.*.pt"
    policy: RslRlPpoActorCriticCfg = MISSING
    algorithm: RslRlPpoAlgorithmCfg = MISSING


@configclass
class BasePPORunnerCfg(RslRlOnPolicyRunnerCfg):
    num_steps_per_env = 24
    max_iterations = 10000
    save_interval = 500
    experiment_name = ""  # same as task name
    empirical_normalization = False
    logger = "wandb"
    wandb_project = "omnibot-go2w"
    obs_groups = {"policy": ["policy"], "critic": ["critic"]}
    policy = RslRlPpoActorCriticCfg(
        init_noise_std=1.0,
        actor_obs_normalization=False,
        critic_obs_normalization=False,
        actor_hidden_dims=[512, 256, 128],
        critic_hidden_dims=[512, 256, 128],
        activation="elu",
    )
    algorithm = RslRlPpoAlgorithmCfg(
        value_loss_coef=1.0,
        use_clipped_value_loss=True,
        clip_param=0.2,
        entropy_coef=0.01,
        num_learning_epochs=5,
        num_mini_batches=4,
        learning_rate=1.0e-3,
        schedule="adaptive",
        gamma=0.99,
        lam=0.95,
        desired_kl=0.01,
        max_grad_norm=1.0,
    )


@configclass
class WFTRON1RoughPPORunnerCfg(RslRlOnPolicyRunnerCfg):
    num_steps_per_env = 24
    max_iterations = 20000
    save_interval = 100
    experiment_name = "limx_wf_tron1_rough"
    empirical_normalization = False
    logger = "wandb"
    wandb_project = "omnibot-tron"
    obs_groups = {"policy": ["policy"], "critic": ["critic"]}
    policy = RslRlPpoActorCriticCfg(
        init_noise_std=1.0,
        actor_obs_normalization=False,
        critic_obs_normalization=False,
        actor_hidden_dims=[512, 256, 128],
        critic_hidden_dims=[512, 256, 128],
        activation="elu",
    )
    algorithm = RslRlPpoAlgorithmCfg(
        value_loss_coef=1.0,
        use_clipped_value_loss=True,
        clip_param=0.2,
        entropy_coef=0.01,
        num_learning_epochs=5,
        num_mini_batches=4,
        learning_rate=1.0e-3,
        schedule="adaptive",
        gamma=0.99,
        lam=0.95,
        desired_kl=0.01,
        max_grad_norm=1.0,
    )


@configclass
class WFTRON1FlatPPORunnerCfg(WFTRON1RoughPPORunnerCfg):
    def __post_init__(self) -> None:
        self.max_iterations = 5000
        self.experiment_name = "limx_wf_tron1_flat"


@configclass
class Go2WFlatMLPPPORunnerCfg(BasePPORunnerCfg):
    def __post_init__(self) -> None:
        self.experiment_name = "omnibot_go2w_flat_mlp_v0"


@configclass
class Go2WGaitMLPPPORunnerCfg(Go2WFlatMLPPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.experiment_name = "omnibot_go2w_gait_flat_mlp_v0"
        self.max_iterations = 5000
        self.policy.noise_std_type = "log"


@configclass
class Go2WGaitCurriculumPPORunnerCfg(Go2WGaitMLPPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.class_name = "GaitCurriculumRunner"
        self.experiment_name = "omnibot_go2w_gait_curriculum_vx5_swing15"
        self.max_iterations = 30000
        self.save_interval = 500
        self.algorithm.learning_rate = 3.0e-4


@configclass
class Go2WJumpMLPPPORunnerCfg(Go2WFlatMLPPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.max_iterations = 5000
        self.experiment_name = "omnibot_go2w_jump_mlp_v0"
        self.resume_experiment_name = self.experiment_name


@configclass
class Go2WHandstandPPORunnerCfg(Go2WFlatMLPPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.experiment_name = "omnibot_go2w_handstand_v0"


@configclass
class Go2WUprightPPORunnerCfg(Go2WFlatMLPPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.experiment_name = "omnibot_go2w_upright_v0"


@configclass
class Go2WCrawlPPORunnerCfg(Go2WFlatMLPPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.experiment_name = "omnibot_go2w_crawl_v0"


@configclass
class Go2WRoughMLPPPORunnerCfg(BasePPORunnerCfg):
    def __post_init__(self) -> None:
        self.experiment_name = "omnibot_go2w_rough_mlp_v0"
        self.policy.noise_std_type = "log"
        self.algorithm.learning_rate = 3.0e-4
        self.algorithm.entropy_coef = 0.008


@configclass
class Go2WHighPlatformMLPPPORunnerCfg(Go2WRoughMLPPPORunnerCfg):
    """Write platform runs separately while allowing Rough warm-starting."""

    def __post_init__(self) -> None:
        super().__post_init__()
        self.max_iterations = 5000
        self.experiment_name = "omnibot_go2w_highplatform_mlp_v0"
        self.resume_experiment_name = "omnibot_go2w_rough_mlp_v0"


@configclass
class DecoderSingleCfg:
    type: Literal["mlp", "vae"] = MISSING
    target_indices: list[int] = MISSING
    loss_weight: float = 1.0
    hidden_dims: list[int] = field(default_factory=lambda: [128, 64])
    activation: str = "elu"
    latent_dim: int = 32


@configclass
class VAEDecoderCfg(DecoderSingleCfg):
    type: Literal["vae"] = "vae"
    kl_weight: float = 1e-3


@configclass
class DecoderCollectionCfg:
    learning_rate: float = 1e-4
    loss_weight: float = 0.01
    configs: list[DecoderSingleCfg] = MISSING


@configclass
class ActorCriticDecoderCfg:
    actor: DecoderCollectionCfg | None = None
    critic: DecoderCollectionCfg | None = None


@configclass
class RecurrentDecoderPpoAlgorithmCfg(RslRlPpoAlgorithmCfg):
    decoder_cfg: ActorCriticDecoderCfg | None = None


@configclass
class RecurrentDecoderPPORunnerCfg(RslRlOnPolicyRunnerCfg):
    num_steps_per_env = 24
    max_iterations = 10000
    save_interval = 500
    experiment_name = ""
    empirical_normalization = True
    # Default to W&B logging for all Go2W decoder-based runners.
    logger = "wandb"
    wandb_project = "omnibot-go2w"
    obs_groups = {"policy": ["policy"], "critic": ["critic"]}
    policy = RslRlPpoActorCriticRecurrentCfg(
        init_noise_std=1.0,
        actor_obs_normalization=True,
        critic_obs_normalization=True,
        actor_hidden_dims=[512, 256, 128],
        critic_hidden_dims=[512, 256, 128],
        activation="elu",
        rnn_type="gru",
        rnn_hidden_dim=512,
        rnn_num_layers=1,
    )
    algorithm = RecurrentDecoderPpoAlgorithmCfg(
        value_loss_coef=1.0,
        use_clipped_value_loss=True,
        clip_param=0.2,
        entropy_coef=0.01,
        num_learning_epochs=5,
        num_mini_batches=4,
        learning_rate=3.0e-4,
        schedule="adaptive",
        gamma=0.99,
        lam=0.95,
        desired_kl=0.005,
        max_grad_norm=1.0,
        decoder_cfg=ActorCriticDecoderCfg(
            actor=DecoderCollectionCfg(
                learning_rate=1.0e-4,
                loss_weight=0.01,
                configs=[
                    VAEDecoderCfg(
                        target_indices=[0, 1, 2],
                        loss_weight=1.0,
                        hidden_dims=[128, 64],
                        activation="elu",
                        latent_dim=32,
                        kl_weight=1.0e-3,
                    )
                ],
            ),
            critic=DecoderCollectionCfg(
                learning_rate=1.0e-4,
                loss_weight=0.01,
                configs=[
                    VAEDecoderCfg(
                        target_indices=[0, 1, 2],
                        loss_weight=1.0,
                        hidden_dims=[128, 64],
                        activation="elu",
                        latent_dim=32,
                        kl_weight=1.0e-3,
                    )
                ],
            ),
        ),
    )


@configclass
class Go2WRecurrentDecoderPPORunnerCfg(RecurrentDecoderPPORunnerCfg):
    """Go2W checkpoint-compatible recurrent optimizer settings."""

    def __post_init__(self) -> None:
        self.empirical_normalization = None
        algorithm = cast(RecurrentDecoderPpoAlgorithmCfg, self.algorithm)
        if algorithm.decoder_cfg is not None:
            if algorithm.decoder_cfg.actor is not None:
                algorithm.decoder_cfg.actor.learning_rate = 3.0e-4
            if algorithm.decoder_cfg.critic is not None:
                algorithm.decoder_cfg.critic.learning_rate = 3.0e-4


@configclass
class Go2WFlatRnnDecoderPPORunnerCfg(Go2WRecurrentDecoderPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.experiment_name = "omnibot_go2w_flat_rnn_v0"
        self.algorithm.desired_kl = 0.01


@configclass
class Go2WRoughRnnDecoderPPORunnerCfg(Go2WRecurrentDecoderPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.experiment_name = "omnibot_go2w_rough_rnn_v0"
        policy = cast(RslRlPpoActorCriticRecurrentCfg, self.policy)
        policy.rnn_hidden_dim = 256
        algorithm = cast(RecurrentDecoderPpoAlgorithmCfg, self.algorithm)
        if algorithm.decoder_cfg is not None:
            algorithm.decoder_cfg.critic = None
        self.algorithm.desired_kl = 0.01


@configclass
class WFTRON1RoughRnnDecoderPPORunnerCfg(RecurrentDecoderPPORunnerCfg):
    max_iterations = 20000
    save_interval = 100
    wandb_project = "omnibot-tron"

    def __post_init__(self) -> None:
        self.experiment_name = "limx_wf_tron1_rough_rnn_v0"
        self.algorithm.desired_kl = 0.01


@configclass
class WFTRON1FlatRnnDecoderPPORunnerCfg(WFTRON1RoughRnnDecoderPPORunnerCfg):
    def __post_init__(self) -> None:
        self.max_iterations = 5000
        self.experiment_name = "limx_wf_tron1_flat_rnn_v0"
        self.algorithm.desired_kl = 0.01


@configclass
class DreamWaQPPORunnerCfg(RslRlOnPolicyRunnerCfg):
    num_steps_per_env = 24
    max_iterations = 10000
    save_interval = 500
    experiment_name = ""
    empirical_normalization = False
    logger = "wandb"
    wandb_project = "omnibot-go2w"
    obs_groups = {"policy": ["policy"], "policy_history": ["policy_history"], "critic": ["critic"]}
    policy = RslRlPpoActorCriticDreamWaQCfg(
        init_noise_std=1.0,
        actor_obs_normalization=True,
        critic_obs_normalization=True,
        actor_hidden_dims=[512, 256, 128],
        critic_hidden_dims=[512, 256, 128],
        estimator_hidden_dims=[128],
        context_decoder_hidden_dims=[64, 128],
        activation="elu",
        history_obs_set="policy_history",
        velocity_target_group="dreamwaq_velocity",
        context_target_group="policy",
        context_latent_dim=16,
        vae_sigma_min=0.0,
        vae_sigma_max=5.0,
        reconstruction_mask_indices=[],
    )
    algorithm = RslRlPpoDreamWaQAlgorithmCfg(
        value_loss_coef=1.0,
        use_clipped_value_loss=True,
        clip_param=0.2,
        entropy_coef=0.01,
        num_learning_epochs=5,
        num_mini_batches=4,
        learning_rate=1.0e-3,
        schedule="adaptive",
        gamma=0.99,
        lam=0.95,
        desired_kl=0.01,
        max_grad_norm=1.0,
        vae_learning_rate=1.0e-3,
        kl_weight=1.0,
    )


@configclass
class Go2WDreamWaQPPORunnerCfg(DreamWaQPPORunnerCfg):
    """Go2W checkpoint-compatible DreamWaQ settings without changing WF-TRON1 defaults."""

    def __post_init__(self) -> None:
        self.empirical_normalization = None
        policy = cast(RslRlPpoActorCriticDreamWaQCfg, self.policy)
        policy.noise_std_type = "log"
        policy.actor_obs_normalization = False
        policy.critic_obs_normalization = False
        algorithm = cast(RslRlPpoDreamWaQAlgorithmCfg, self.algorithm)
        algorithm.learning_rate = 3.0e-4
        algorithm.vae_learning_rate = 3.0e-4


@configclass
class Go2WFlatDreamWaQPPORunnerCfg(Go2WDreamWaQPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.experiment_name = "omnibot_go2w_flat_dreamwaq_v0"
        self.policy.reconstruction_mask_indices = [6, 7, 8, *range(37, 53)]


@configclass
class Go2WRoughDreamWaQPPORunnerCfg(Go2WDreamWaQPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.experiment_name = "omnibot_go2w_rough_dreamwaq_v0"
        self.algorithm.entropy_coef = 0.008
        self.policy.reconstruction_mask_indices = [6, 7, 8, *range(37, 53)]


@configclass
class Go2WRecoverDreamWaQPPORunnerCfg(Go2WRoughDreamWaQPPORunnerCfg):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.max_iterations = 5000
        self.experiment_name = "omnibot_go2w_recover_dreamwaq_v0"


@configclass
class WFTRON1DreamWaQPPORunnerCfg(DreamWaQPPORunnerCfg):
    max_iterations = 20000
    save_interval = 100
    wandb_project = "omnibot-tron"


@configclass
class WFTRON1RoughDreamWaQPPORunnerCfg(WFTRON1DreamWaQPPORunnerCfg):
    def __post_init__(self) -> None:
        self.experiment_name = "limx_wf_tron1_rough_dreamwaq"


@configclass
class WFTRON1FlatDreamWaQPPORunnerCfg(WFTRON1DreamWaQPPORunnerCfg):
    def __post_init__(self) -> None:
        self.max_iterations = 5000
        self.experiment_name = "limx_wf_tron1_flat_dreamwaq"
