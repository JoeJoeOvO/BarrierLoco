"""Locomotion module for LocoLab."""
